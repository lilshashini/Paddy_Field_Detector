# Detect And Classify Instance Segmentation > 2025-05-25 10:15pm
https://universe.roboflow.com/paddydetection/detect-and-classify-instance-segmentation-ovisb

Provided by a Roboflow user
License: CC BY 4.0

